# MusicWave

App Android de música (Kotlin + Jetpack Compose + Media3). Toca arquivos de áudio locais, funciona offline.

## Como gerar o APK
1. Instale o Android Studio (versão recente) e abra a pasta `MusicWave`.
2. Aguarde o "Gradle Sync" terminar (precisa de internet na primeira vez).
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`. Copie para o celular e instale (permita "fontes desconhecidas").

Ou, pelo terminal (com o Gradle 8.7 instalado): `gradle assembleDebug`

## Funcionalidades
- Lista de músicas do aparelho com capa, nome e artista; pesquisa
- Play/pause, anterior/próxima, barra de progresso, volume
- Aleatório e repetição (desligada / todas / uma)
- Favoritos, playlists (criar, renomear, excluir, adicionar/remover músicas), histórico
- Reprodução em segundo plano, notificação e controles na tela de bloqueio
- Modo escuro automático (segue o sistema)

## Estrutura
- `data/` — Song, leitura do MediaStore, armazenamento local (favoritos, playlists, histórico)
- `playback/PlaybackService.kt` — ExoPlayer + MediaSession (segundo plano/notificação)
- `ui/MusicViewModel.kt` — estado do app e controle do player
- `ui/MusicWaveApp.kt` — telas em Compose
- `MainActivity.kt` — permissões e ponto de entrada

Requisitos: Android 8.0+ (API 26). Use apenas músicas que você tem autorização para usar.
