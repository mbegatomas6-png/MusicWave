package com.musicwave.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Guarda favoritos, playlists e histórico localmente (SharedPreferences). */
class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("musicwave", Context.MODE_PRIVATE)

    private fun readIds(key: String): List<Long> =
        (prefs.getString(key, "") ?: "").split(",").mapNotNull { it.toLongOrNull() }

    fun loadFavorites(): Set<Long> = readIds("fav").toSet()
    fun saveFavorites(s: Set<Long>) {
        prefs.edit().putString("fav", s.joinToString(",")).apply()
    }

    fun loadHistory(): List<Long> = readIds("hist")
    fun saveHistory(l: List<Long>) {
        prefs.edit().putString("hist", l.joinToString(",")).apply()
    }

    fun loadPlaylists(): Map<String, List<Long>> {
        val out = LinkedHashMap<String, List<Long>>()
        try {
            val obj = JSONObject(prefs.getString("pl", "{}") ?: "{}")
            val keys = obj.keys()
            while (keys.hasNext()) {
                val name = keys.next()
                val arr = obj.getJSONArray(name)
                out[name] = (0 until arr.length()).map { arr.getLong(it) }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun savePlaylists(m: Map<String, List<Long>>) {
        val obj = JSONObject()
        m.forEach { (name, ids) ->
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            obj.put(name, arr)
        }
        prefs.edit().putString("pl", obj.toString()).apply()
    }
}
