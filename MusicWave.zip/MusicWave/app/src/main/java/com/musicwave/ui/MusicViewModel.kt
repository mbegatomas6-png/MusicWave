package com.musicwave.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.musicwave.data.LibraryStore
import com.musicwave.data.Song
import com.musicwave.data.SongRepository
import com.musicwave.playback.PlaybackService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MusicViewModel(app: Application) : AndroidViewModel(app) {

    private val store = LibraryStore(app)
    private var controller: MediaController? = null

    var songs by mutableStateOf<List<Song>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var query by mutableStateOf("")
    var favorites by mutableStateOf(store.loadFavorites()); private set
    var playlists by mutableStateOf(store.loadPlaylists()); private set
    var history by mutableStateOf(store.loadHistory()); private set

    var currentId by mutableStateOf<Long?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set
    var volume by mutableFloatStateOf(1f); private set

    val visibleSongs: List<Song>
        get() {
            val q = query.trim()
            if (q.isEmpty()) return songs
            return songs.filter {
                it.title.contains(q, ignoreCase = true) ||
                    it.artist.contains(q, ignoreCase = true) ||
                    it.album.contains(q, ignoreCase = true)
            }
        }

    val currentSong: Song? get() = songById(currentId)

    fun songById(id: Long?): Song? = if (id == null) null else songs.firstOrNull { it.id == id }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            this@MusicViewModel.isPlaying = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val id = mediaItem?.mediaId?.toLongOrNull()
            currentId = id
            positionMs = 0L
            durationMs = songById(id)?.durationMs ?: 0L
            if (id != null) addToHistory(id)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            shuffle = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            this@MusicViewModel.repeatMode = repeatMode
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                currentId = c.currentMediaItem?.mediaId?.toLongOrNull()
                isPlaying = c.isPlaying
                shuffle = c.shuffleModeEnabled
                repeatMode = c.repeatMode
                volume = c.volume
                positionMs = c.currentPosition
                durationMs = songById(currentId)?.durationMs ?: 0L
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                controller?.let {
                    if (it.isPlaying) {
                        positionMs = it.currentPosition
                        durationMs = if (it.duration > 0) it.duration else durationMs
                    }
                }
                delay(500)
            }
        }
    }

    fun loadSongs() {
        viewModelScope.launch {
            loading = true
            songs = SongRepository.load(getApplication())
            loading = false
            if (currentId != null) durationMs = songById(currentId)?.durationMs ?: durationMs
        }
    }

    private fun toItem(s: Song): MediaItem =
        MediaItem.Builder()
            .setMediaId(s.id.toString())
            .setUri(s.uri)
            .setRequestMetadata(
                MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(s.uri)).build()
            )
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(s.title)
                    .setArtist(s.artist)
                    .setAlbumTitle(s.album)
                    .setArtworkUri(SongRepository.albumArtUri(s.albumId))
                    .build()
            )
            .build()

    // ---- Reprodução ----
    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map { toItem(it) }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        positionMs = ms
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun setVolume(v: Float) {
        volume = v
        controller?.volume = v
    }

    // ---- Favoritos ----
    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        store.saveFavorites(favorites)
    }

    // ---- Histórico ----
    private fun addToHistory(id: Long) {
        history = (listOf(id) + history.filter { it != id }).take(50)
        store.saveHistory(history)
    }

    // ---- Playlists ----
    private fun savePlaylists(m: Map<String, List<Long>>) {
        playlists = m
        store.savePlaylists(m)
    }

    fun createPlaylist(name: String) {
        if (name.isBlank() || playlists.containsKey(name)) return
        savePlaylists(playlists + (name to emptyList<Long>()))
    }

    fun renamePlaylist(old: String, new: String) {
        if (new.isBlank() || (new != old && playlists.containsKey(new))) return
        savePlaylists(playlists.mapKeys { if (it.key == old) new else it.key })
    }

    fun deletePlaylist(name: String) {
        savePlaylists(playlists - name)
    }

    fun addToPlaylist(name: String, id: Long) {
        val cur = playlists[name] ?: return
        if (id in cur) return
        savePlaylists(playlists + (name to (cur + id)))
    }

    fun removeFromPlaylist(name: String, id: Long) {
        val cur = playlists[name] ?: return
        savePlaylists(playlists + (name to (cur - id)))
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
