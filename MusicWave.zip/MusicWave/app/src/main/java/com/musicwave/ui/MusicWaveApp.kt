package com.musicwave.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.musicwave.data.Song
import com.musicwave.data.SongRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- Tema

@Composable
fun MusicWaveTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFFB9A8FF))
        else -> lightColorScheme(primary = Color(0xFF6C4DFF))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------------------------------------------------------------- Raiz

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicWaveApp(vm: MusicViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var openPlaylist by remember { mutableStateOf<String?>(null) }
    var addTarget by remember { mutableStateOf<Song?>(null) }

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && openPlaylist != null) { openPlaylist = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("MusicWave") },
                    actions = {
                        IconButton(onClick = { vm.loadSongs() }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Atualizar lista")
                        }
                    }
                )
            },
            bottomBar = {
                Column {
                    MiniPlayer(vm) { showPlayer = true }
                    NavigationBar {
                        val items = listOf(
                            "Músicas" to Icons.Filled.MusicNote,
                            "Favoritas" to Icons.Filled.Favorite,
                            "Playlists" to Icons.Filled.LibraryMusic,
                            "Histórico" to Icons.Filled.History
                        )
                        items.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i; openPlaylist = null },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> LibraryTab(vm) { addTarget = it }
                    1 -> SongList(
                        vm,
                        vm.songs.filter { it.id in vm.favorites },
                        "Nenhuma música favorita ainda.\nToque no coração para favoritar."
                    ) { addTarget = it }
                    2 -> PlaylistsTab(vm, openPlaylist, { openPlaylist = it })
                    else -> SongList(
                        vm,
                        vm.history.mapNotNull { vm.songById(it) },
                        "O histórico está vazio.\nAs músicas que você ouvir aparecem aqui."
                    ) { addTarget = it }
                }
            }
        }

        AnimatedVisibility(
            visible = showPlayer,
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            PlayerScreen(vm) { showPlayer = false }
        }
    }

    addTarget?.let { s -> AddToPlaylistDialog(vm, s) { addTarget = null } }
}

// ---------------------------------------------------------------- Biblioteca

@Composable
private fun LibraryTab(vm: MusicViewModel, onAdd: (Song) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            singleLine = true,
            placeholder = { Text("Pesquisar música, artista ou álbum") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (vm.query.isNotEmpty()) {
                    IconButton(onClick = { vm.query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "Limpar")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
        )
        Box(Modifier.weight(1f)) {
            if (vm.loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                SongList(
                    vm,
                    vm.visibleSongs,
                    if (vm.query.isBlank())
                        "Nenhuma música encontrada no aparelho.\nCopie arquivos de áudio para o celular e toque em atualizar."
                    else "Nada encontrado para a pesquisa.",
                    onAdd
                )
            }
        }
    }
}

@Composable
private fun SongList(vm: MusicViewModel, list: List<Song>, emptyText: String, onAdd: (Song) -> Unit) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyText, textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(list, key = { i, s -> "$i-${s.id}" }) { i, s ->
            SongRow(s, s.id == vm.currentId, onClick = { vm.play(list, i) }) {
                IconButton(onClick = { vm.toggleFavorite(s.id) }) {
                    Icon(
                        if (s.id in vm.favorites) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Favoritar",
                        tint = if (s.id in vm.favorites) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { onAdd(s) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Adicionar à playlist")
                }
            }
        }
    }
}

@Composable
private fun SongRow(song: Song, current: Boolean, onClick: () -> Unit, actions: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt(song, 48.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                song.artist,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        actions()
    }
}

// ---------------------------------------------------------------- Playlists

@Composable
private fun PlaylistsTab(vm: MusicViewModel, open: String?, onOpen: (String?) -> Unit) {
    var showCreate by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }

    if (open != null && vm.playlists.containsKey(open)) {
        val songs = vm.playlists[open].orEmpty().mapNotNull { vm.songById(it) }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onOpen(null) }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                }
                Text(
                    open,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { showRename = true }) {
                    Icon(Icons.Filled.Edit, contentDescription = "Renomear")
                }
                IconButton(onClick = { vm.deletePlaylist(open); onOpen(null) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Excluir playlist")
                }
            }
            Button(
                onClick = { vm.play(songs, 0) },
                enabled = songs.isNotEmpty(),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) { Text("Tocar tudo") }

            if (songs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Playlist vazia.\nUse o botão + em uma música para adicionar.",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(songs, key = { i, s -> "$i-${s.id}" }) { i, s ->
                        SongRow(s, s.id == vm.currentId, onClick = { vm.play(songs, i) }) {
                            IconButton(onClick = { vm.removeFromPlaylist(open, s.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Remover da playlist")
                            }
                        }
                    }
                }
            }
        }
        if (showRename) {
            NameDialog("Renomear playlist", open, { showRename = false }) { newName ->
                vm.renamePlaylist(open, newName.trim())
                onOpen(newName.trim())
                showRename = false
            }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Button(onClick = { showCreate = true }, modifier = Modifier.padding(12.dp)) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("  Nova playlist")
            }
            if (vm.playlists.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Você ainda não criou playlists.", textAlign = TextAlign.Center)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.playlists.keys.toList(), key = { it }) { name ->
                        ListItem(
                            headlineContent = { Text(name) },
                            supportingContent = { Text("${vm.playlists[name].orEmpty().size} músicas") },
                            leadingContent = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
                            modifier = Modifier.clickable { onOpen(name) }
                        )
                    }
                }
            }
        }
        if (showCreate) {
            NameDialog("Nova playlist", "", { showCreate = false }) { name ->
                vm.createPlaylist(name.trim())
                showCreate = false
            }
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, label = { Text("Nome") })
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun AddToPlaylistDialog(vm: MusicViewModel, song: Song, onDismiss: () -> Unit) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (vm.playlists.isEmpty()) Text("Você ainda não tem playlists.")
                vm.playlists.keys.forEach { n ->
                    TextButton(onClick = { vm.addToPlaylist(n, song.id); onDismiss() }) { Text(n) }
                }
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    label = { Text("Nova playlist") },
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = newName.isNotBlank(),
                onClick = {
                    val n = newName.trim()
                    vm.createPlaylist(n)
                    vm.addToPlaylist(n, song.id)
                    onDismiss()
                }
            ) { Text("Criar e adicionar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ---------------------------------------------------------------- Player

@Composable
private fun MiniPlayer(vm: MusicViewModel, onOpen: () -> Unit) {
    val song = vm.currentSong ?: return
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Column {
            LinearProgressIndicator(
                progress = { if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AlbumArt(song, 44.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                    Text(
                        song.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                IconButton(onClick = { vm.togglePlay() }) {
                    Icon(
                        if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (vm.isPlaying) "Pausar" else "Tocar"
                    )
                }
                IconButton(onClick = { vm.next() }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Próxima")
                }
            }
        }
    }
}

@Composable
private fun PlayerScreen(vm: MusicViewModel, onClose: () -> Unit) {
    val song = vm.currentSong
    var dragging by remember { mutableStateOf<Float?>(null) }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Fechar player")
                }
                Text("Tocando agora", modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                Box(Modifier.size(48.dp))
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                AlbumArt(song, 280.dp)
            }

            Text(
                song?.title ?: "Nada tocando",
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(song?.artist ?: "", color = dim, maxLines = 1, overflow = TextOverflow.Ellipsis)

            Slider(
                value = dragging ?: vm.positionMs.toFloat(),
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { vm.seekTo(it.toLong()) }
                    dragging = null
                },
                valueRange = 0f..maxOf(1f, vm.durationMs.toFloat()),
                modifier = Modifier.padding(top = 12.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime((dragging ?: vm.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.bodySmall)
                Text(formatTime(vm.durationMs), style = MaterialTheme.typography.bodySmall)
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleShuffle() }) {
                    Icon(Icons.Filled.Shuffle, contentDescription = "Aleatório", tint = if (vm.shuffle) primary else dim)
                }
                IconButton(onClick = { vm.previous() }) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Anterior", modifier = Modifier.size(36.dp))
                }
                FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(64.dp)) {
                    Icon(
                        if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (vm.isPlaying) "Pausar" else "Tocar",
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onClick = { vm.next() }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Próxima", modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = { vm.cycleRepeat() }) {
                    Icon(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = "Repetir",
                        tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) dim else primary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (song != null) {
                    IconButton(onClick = { vm.toggleFavorite(song.id) }) {
                        Icon(
                            if (song.id in vm.favorites) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favoritar",
                            tint = if (song.id in vm.favorites) primary else dim
                        )
                    }
                }
                Icon(Icons.Filled.VolumeUp, contentDescription = "Volume", tint = dim)
                Slider(
                    value = vm.volume,
                    onValueChange = { vm.setVolume(it) },
                    valueRange = 0f..1f,
                    modifier = Modifier.weight(1f).padding(start = 8.dp)
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Utilidades

private fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun AlbumArt(song: Song?, size: Dp) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song?.id) {
        value = if (song == null) null else withContext(Dispatchers.IO) { loadArt(ctx, song) }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.secondaryContainer),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                Icons.Filled.MusicNote,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.size(size / 2)
            )
        }
    }
}

private fun loadArt(ctx: android.content.Context, song: Song): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(android.net.Uri.parse(song.uri), Size(512, 512), null)
    } else {
        ctx.contentResolver.openInputStream(SongRepository.albumArtUri(song.albumId))
            ?.use { BitmapFactory.decodeStream(it) }
    }
} catch (e: Exception) {
    null
}
